package vo.seller;

public class FoodCategoryVo {

	int food_category_idx;
	String food_category_name;

	private void food_category() {
		// TODO Auto-generated method stub

	}
	
	
	public int getFood_category_idx() {
		return food_category_idx;
	}

	public void setFood_category_idx(int food_category_idx) {
		this.food_category_idx = food_category_idx;
	}

	public String getFood_category_name() {
		return food_category_name;
	}

	public void setFood_category_name(String food_category_name) {
		this.food_category_name = food_category_name;
	}

}
