# 2024.01.23 AM 05:34 File Update

index.jsp로 변경 (UI수정, 지저분한 코드정리, incrude 방식으로 적용)
- header.jsp
- navi.jsp
- footer.jsp

% asset 폴더 다시 받으세욥. CSS, img 수정

- signup.html 수정 (DB col name 맞춤) - jsp로 변경예정
- index.html 수정 (보관용)

----------------------------------------------------------
# miniproject1

첫번째 미니프로젝트 2024.01.22 ~ 01. 30 

