	/*

	-- 병훈님 실제 사용한 쿼리문입니다.(시작)
	create table user 
	(
		 user_idx  			 int primary key not null auto_increment,
		 user_name  	 	 varchar(100) not null,
		 user_id    		 varchar(100) unique not null,
		 user_pwd   	 	 varchar(100) not null,
		 user_cellphone		 varchar(100) not null,
		 user_email	         varchar(100) not null,
		 user_addr			 varchar(100),
		 user_order_addr     varchar(100),
		 user_grade          varchar(100) not null,
		 user_created_date   datetime default now(),
		 user_modified_date  datetime default now(),
		 user_proof			 text
	)
	
	select * from user
	desc user
	desc coupon
	desc seller
	desc food_category
	create table coupon
	(
		coupon_idx          	int primary key not null auto_increment,
		user_idx               	int ,
		user_id					varchar(100),
		coupon_name             varchar(100),
		coupon_content			varchar(100),
		deducted_price			int,
		coupon_min_order_price  int default 20000,
		coupon_created_date     datetime default now(),
		coupon_expired_date     datetime ,
		coupon_status           varchar(100) default '사용가능',
		coupon_issued			varchar(100) default 'N'
	)
	
	alter table coupon add constraint fk_coupon_user_idx foreign key(user_idx) references user(user_idx);
	
	select * from coupon where coupon_name=? and user_id=? and user_idx=?
	
	select * from coupon
	insert into coupon (coupon_name, coupon_content, deducted_price, coupon_expired_date) values('Welcome Coupon1', 'Welcome', 1,now())
	create table food_category 
	(
		food_category_idx    int primary key auto_increment, 
		food_category_name   varchar(100)
	)
	alter table menu add constraint fk_menu_category foreign key(menu_category_idx) references menu_category(menu_category_idx)
	desc seller
	
	desc menu
	
	insert into food_category(food_category_name) values("전통시장");
	insert into food_category(food_category_name) values("한식");
	insert into food_category(food_category_name) values("중식");
	insert into food_category(food_category_name) values("일식");
	insert into food_category(food_category_name) values("아시안");
	insert into food_category(food_category_name) values("야식");
	insert into food_category(food_category_name) values("분식");
	insert into food_category(food_category_name) values("디저트");
	insert into food_category(food_category_name) values("양식");
	
	
	create table seller  
	(
		seller_idx				int primary key auto_increment,
		seller_name				varchar(100) not null,
		seller_addr				varchar(100),
		seller_photo			text,
		seller_phone			varchar(100) not null,
		delivery_type			varchar(100) default 0,
		seller_intro			text,
		seller_min_order_price	int default 0,
		seller_rating			int,
		seller_review_num       int default 0,
		seller_operation_hours  varchar(100) ,
		seller_close_days       varchar(100) ,
		seller_created_date     datetime default now(),
		seller_modified_date	datetime default now(),
		seller_status			varchar(100) not null,
		food_category_idx		int ,
		food_category_name		varchar(100),
		user_idx				int,
		seller_photo_ip			varchar(200)
	)
	
	desc seller
	desc menu
	select * from menu
	alter table menu add constraint	fk_menu foreign key(seller_idx) references seller(seller_idx)
	alter table coupon add constraint fk_coupon_user_idx foreign key(user_idx) references user(user_idx)
	
	delete from menu where menu_idx=7
	alter table seller add constraint fk_seller_food_category_idx foreign key(food_category_idx) references food_category(food_category_idx)
	alter table seller add constraint fk_user_idx foreign key(user_idx) references user(user_idx)
	
	create table menu_category
	(
		menu_category_idx  int primary key auto_increment,
		menu_category_name varchar(100) not null
	)
	
	insert into menu_category(menu_category_name) values("식사류");
	insert into menu_category(menu_category_name) values("디저트류");
	insert into menu_category(menu_category_name) values("음료");
	insert into menu_category(menu_category_name) values("주류");
	
	create table menu
	(
		menu_idx			int primary key not null auto_increment,
		seller_idx			int not null,
		menu_name			varchar(100) not null,
		menu_category_idx   int not null,
		menu_category_name	varchar(100),
		menu_photo          text,
		menu_price          int not null,
		menu_created_date   datetime default now(),
		menu_modified_date  datetime default now(),
		menu_status			varchar(100) default "주문가능",
		menu_rating_avg     int,
		menu_photo_ip		varchar(200),
		menu_detail			varchar(100)
	)
	
	alter table menu add constraint fk_menu_menu_category_idx foreign key(menu_category_idx) references menu_category(menu_category_idx);
	alter table menu add constraint fk_menu_seller_idx foreign key(seller_idx) references seller(seller_idx);
	
	
	
	
*/
